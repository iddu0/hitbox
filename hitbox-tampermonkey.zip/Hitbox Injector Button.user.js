// ==UserScript==
// @name         Hitbox Injector Button
// @namespace    http://teamhitbox.github.io/
// @version      1.1
// @description  Adds a button to inject Hitbox
// @author       you
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // create the button
    const btn = document.createElement('button');
    btn.textContent = 'Inject Hitbox';
    btn.style.position = 'fixed';
    btn.style.bottom = '20px';
    btn.style.right = '20px';
    btn.style.padding = '10px 15px';
    btn.style.backgroundColor = '#22C35D';
    btn.style.color = 'white';
    btn.style.border = 'none';
    btn.style.borderRadius = '8px';
    btn.style.cursor = 'pointer';
    btn.style.zIndex = '9999';
    btn.style.fontSize = '14px';
    btn.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';

    // inject script on click and remove button
    btn.addEventListener('click', () => {
        const script = document.createElement('script');
        script.src = 'https://teamhitbox.github.io/hitbox/client/book.js';
        script.type = 'text/javascript';
        document.head.appendChild(script);

        // remove the button after injection
        btn.remove();
    });

    // add button to page
    document.body.appendChild(btn);
})();
